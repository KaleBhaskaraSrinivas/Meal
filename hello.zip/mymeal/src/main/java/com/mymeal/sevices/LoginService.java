package com.mymeal.sevices;

import com.mymeal.models.User;

public interface LoginService {

	boolean checkUserCredentials(String empId, String password);

	boolean registerUser(User user);

	String generateRandomToken();

	boolean saveRandomstring(String empId, String ran);

	boolean saveEmployeeRole(String empId);

	String getRoleById(String empId);

	int sendmail(String to_mail);

	int generateOTP();

	void sendEmail(String to, String subject, String body);

	int resetpwd(String email, String pwd, String cnfpwd, String employeeId);
	

}