package com.mymeal.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mymeal.models.User;
import com.mymeal.rowmappers.UserRowMapper;
import com.mymeal.rowmappers.EmpRoleRowMapper;

@Repository
public class UserDao {

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public UserDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean checkUserCredentials(String empId, String password) {
		String sql = "SELECT * FROM emp_users WHERE emp_id = ? AND password = ?";
		List<User> userList = jdbcTemplate.query(sql, new Object[] { empId + "", password }, new UserRowMapper());

		return !userList.isEmpty();
	}

	public boolean registerUser(User user) {
		try {
			String sql = "INSERT INTO emp_users (username, email,emp_id, phone_no, password,repeat_password) VALUES (?, ?, ?, ?, ?,?)";
			jdbcTemplate.update(sql, user.getUsername(), user.getEmail(), user.getEmployeid(), user.getPhoneNo(),
					user.getPassword(), user.getRepeatPassword());
			return true;
		} catch (Exception e) {
			// Log the exception or handle it as needed
			e.printStackTrace();
			return false;
		}
	}

	public boolean saveRandomstring(String empId, String random) {
		try {
			String sql = "INSERT INTO emp_key (empId,key) VALUES (?, ?)";
			jdbcTemplate.update(sql, empId, random);


			return true;
		} catch (Exception e) {
			// Log the exception or handle it as needed
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	

	public boolean saveEmployeeRole(String empId) {
		try {
			String sql = "INSERT INTO emp_role (empId,role) VALUES (?, ?)";
			jdbcTemplate.update(sql, empId, "user");
			
			return true;
		} catch (Exception e) {
			// Log the exception or handle it as needed
			e.printStackTrace();
			return false;
		}
	}

	public String getRoleById(String empId) {
	    String sql = "SELECT role FROM emp_role WHERE empId = ?";
	    return jdbcTemplate.queryForObject(sql, new Object[]{empId}, String.class);
	}

	
	public int resetpwd(String email, String pwd, java.lang.String empId) {
		String sql = "UPDATE updatePasswordTable SET username = ?, password = ? WHERE userId = ?";
		return jdbcTemplate.update(sql, email, pwd, empId);
	}

}
