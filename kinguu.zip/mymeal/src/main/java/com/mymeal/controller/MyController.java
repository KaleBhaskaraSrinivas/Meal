package com.mymeal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mymeal.models.User;
import com.mymeal.sevices.LoginService;

import jakarta.servlet.http.HttpSession;

@Controller

public class MyController {

	private LoginService loginservice;
	HttpSession session;

	@Autowired
	public MyController(LoginService loginservice, HttpSession session) {
		this.loginservice = loginservice;
		this.session = session;
	}

	@GetMapping("/adminLogin")
	public String showAdminLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "adminLoginPage"; // This should match the Thymeleaf template name (signup.html)
	}

	@GetMapping("/employeeSignup")
	public String showSignupForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "empSignup"; // This should match the Thymeleaf template name (signup.html)
	}

	@RequestMapping(value = "/sign", method = RequestMethod.POST)
	public String userSignup(@ModelAttribute("user") User user, Model model) {
		// Perform validation or other necessary checks
		if (!user.getPassword().equals(user.getRepeatPassword())) {
			model.addAttribute("error", "Passwords do not match");
			return "empSignup";
		}

		// Call the service to register the user
		boolean isUserRegistered = loginservice.registerUser(user);

		if (isUserRegistered) {
			System.out.println(isUserRegistered + "registered");
			return "success";
		}

		System.out.println("User registration failed");
		model.addAttribute("error", "User registration failed");
		return "signup-failed";
	}

	@GetMapping("/empLog")
	public String showLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "empLogin"; // This should match the Thymeleaf template name (signup.html)
	}

	@PostMapping("/check")
	public String userLogin(@RequestParam("empId") String empId, @RequestParam("password") String password,
			Model model) {

		// Assuming you have a method in UserRepository to check user credentials
		boolean isValidUser = loginservice.checkUserCredentials(Integer.parseInt(empId), password);

		if (isValidUser) {

			String ran = loginservice.generateRandomToken();
			session.setAttribute("authenticationToken", ran);

			boolean result = loginservice.saveRandomstring(empId, ran);

			String s = (String) session.getAttribute("authenticationToken");

			return "success";
		}

		System.out.println("Invalid credentials");
		model.addAttribute("error", "Invalid credentials");
		return "empLogin";
	}
}
