package com.mymeal.sevices;

import com.mymeal.models.User;

public interface LoginService {

	boolean checkUserCredentials(int empId, String password);

	boolean registerUser(User user);

	String generateRandomToken();

	boolean saveRandomstring(String empId, String ran);

}
