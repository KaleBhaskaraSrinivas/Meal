package com.mymeal.sevices;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mymeal.daos.UserDao;
import com.mymeal.models.User;

import jakarta.servlet.http.HttpSession;

@Service
public class LoginServiceImpl implements LoginService {
	public UserDao userDao;
	HttpSession session;

	@Autowired
	public LoginServiceImpl(UserDao userDao, HttpSession session) {
		this.userDao = userDao;
		this.session = session;
	}

	@Override
	public boolean checkUserCredentials(int empId, String password) {
		boolean b = userDao.checkUserCredentials(empId, password);

		return b;
	}

	@Override
	public boolean registerUser(User user) {
		boolean b = userDao.registerUser(user);
		return b;
	}

	@Override
	public String generateRandomToken() {
		return UUID.randomUUID().toString();
	}

	@Override
	public boolean saveRandomstring(String empId, String ran) {
		return userDao.saveRandomstring(empId, ran);

	}

}
