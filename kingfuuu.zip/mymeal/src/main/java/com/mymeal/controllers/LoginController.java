package com.mymeal.controllers;

import java.time.LocalTime;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mymeal.models.User;
import com.mymeal.services.LoginService;

import jakarta.servlet.http.HttpSession;

@Controller

public class LoginController {

	private LoginService loginservice;
	HttpSession session;

	@Autowired
	public LoginController(LoginService loginservice, HttpSession session) {
		this.loginservice = loginservice;
		this.session = session;
	}

	@GetMapping("/adminLogin")
	public String showAdminLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "adminLoginPage";
	}

	@GetMapping("/employeeSignup")
	public String showSignupForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "signup";
	}

	@RequestMapping(value = "/sign", method = RequestMethod.POST)
	public String userSignup(@ModelAttribute User user, Model model) {

		System.out.println(user);

		// Perform validation or other necessary checks
		if (!user.getPassword().equals(user.getRepeatPassword())) {
			model.addAttribute("error", "Passwords do not match");
			return "signup";
		}

		// Call the service to register the user
		boolean isUserRegistered = loginservice.registerUser(user);

		if (isUserRegistered) {
			System.out.println(isUserRegistered + "registered");
			return "MenuList";
		}

		System.out.println("User registration failed");
		model.addAttribute("error", "User registration failed");
		return "signup-failed";
	}

	@GetMapping("/empLog")
	public String showLoginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);

		return "empLogin"; // This should match the Thymeleaf template name (signup.html)
	}

	@GetMapping("/check")
	public String userLogin(@RequestParam("empId") String empId, @RequestParam("password") String password,
			Model model) {

		// Assuming you have a method in UserRepository to check user credentials
		boolean isValidUser = loginservice.checkUserCredentials(empId, password);

		System.out.println(isValidUser + "sad");

		if (isValidUser) {

			String ran = loginservice.generateRandomToken();
			session.setAttribute("authenticationToken", ran);
			session.setAttribute("empId", empId);

			boolean result = loginservice.saveRandomstring(empId, ran);

			loginservice.saveEmployeeRole(empId);

			String role = loginservice.getRoleById(empId);
			// String s = (String) session.getAttribute("authenticationToken");

			if (role.equals("admin")) {
				return "addItems";
			} else {
				return "MenuList";
			}

		}

		System.out.println("Invalid credentials");
		model.addAttribute("error", "Invalid credentials");
		return "index";
	}

	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {
		try {

			String email = to_mail;

			System.out.println(email + "emailll");
			session.setAttribute("email", email);
			// storing generated otp
			int OTP = loginservice.sendmail(to_mail);
			System.out.println("otpp" + OTP);

			LocalTime currentTime = LocalTime.now();
			session.setAttribute("time", currentTime.plusMinutes(5));
			session.setAttribute("OTP", OTP);
			return "Email Sent Successfully";
		} catch (Exception e) {

			throw e; // rethrow the exception for global exception handling
		}
	}

	// Validate OTP
	@PostMapping(value = "/validateOTP")
	public ArrayList<String> validateOTP(@RequestParam("otp") String otp, Model model) {
		try {

			ArrayList<String> result = new ArrayList<>();
			model.addAttribute("to", "");
			int OTP = Integer.parseInt(otp);
			ModelAndView mav = new ModelAndView();
			int originalOtp = (Integer) session.getAttribute("OTP");
			String email = (String) session.getAttribute("email");

			LocalTime time = (LocalTime) session.getAttribute("time");
			int comp = time.compareTo(LocalTime.now());
			// checking the otp sent by the user if true returning reset page else need to
			// stay in the same page with error
			// msg

			if (originalOtp == OTP && comp > 0) {
				mav.setViewName("reset");
				mav.addObject("email", email);
				result.add("success");

				return result;
			}
			if (comp < 0) {
				result.add("expired");
				result.add("-1");

				return result;
			} else {
				result.add("invalid");
				result.add("-1");

				return result;
			}
		} catch (Exception e) {

			throw e; // rethrow the exception for global exception handling
		}
	}

	// Reset user password
	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		try {
			String employeeId = (String) session.getAttribute("empId");

			int x = loginservice.resetpwd(email, pwd, cnfpwd, employeeId);
			if (x > 0) {

				return "password Changed";
			} else {

				return "password not match";
			}
		} catch (Exception e) {

			throw e; // rethrow the exception for global exception handling
		}
	}

}
