package com.mymeal.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mymeal.models.User;

public class UserRowMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		User user = new User();

		user.setEmployeeid(resultSet.getString("emp_id"));

		user.setPassword(resultSet.getString("password"));

		// Additional mappings if needed

		return user;
	}
}
